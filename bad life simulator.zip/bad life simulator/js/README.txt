this is where all the javascript for the game goes.

activitiesjs is where the javascript used for activities goes, so as to make the integral javascript found in this folder, the ones that do variable initialisation and other essential functions, easy to find and distinguish.

DNW-legacy is where javascript files that either Did Not Work (DNW) or used to be used but have been replaced by a better method (legacy). this folder is mostly just for safekeeping if something goes wrong with the newer code, there's something to substitute in and fall back on without rewriting an entire strip of code.