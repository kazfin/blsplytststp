fonts and images go here.

you are welcome to use any of the assets listed here already, as they're free to use (if you're doing a mod you should make your own logo though. the logo/fav for the official bad life simulator is intellectual property and not free to use for consumer protection purposes and protecting the integrity of the original brand. i recommend using a program like GIMP (which is free) or photoshop to create it.) the .xcf files provided are GIMP project files that you can use to edit some of these icons.

the SVG icons came from tabler.io.

to round icon borders, i recommend either using the built-in css border-radius: x; feature or, if they need to be burned directly into the image, pinetools.com/round-corners-image.

some images may simply be too large and need to be smaller in order for the pages to load quickly, and for that i recommend tinypng.com, which compresses images to up to 80% smaller file sizes completely losslessly.